import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Sparkles, Shirt, MessageCircleHeart, CalendarClock, BarChart3, ScanFace, Crown } from 'lucide-react'

const FEATURES = [
  {
    icon: Sparkles,
    title: 'AI Outfit Generator',
    desc: 'Generates a complete outfit from your own closet with a match score, styling reasoning, and three alternatives — no guesswork.',
    color: 'from-violet/25 to-violet/5',
    iconColor: 'text-violet',
    tags: ['Match score', 'Reasoning', '3 alternatives'],
    span: 'sm:col-span-2 lg:col-span-2 lg:row-span-2',
    big: true,
  },
  {
    icon: Shirt,
    title: 'My Closet',
    desc: 'Snap a photo of every piece you own and build a searchable digital wardrobe, tagged by category and color.',
    color: 'from-indigo/25 to-indigo/5',
    iconColor: 'text-indigo',
    span: 'lg:col-span-2',
  },
  {
    icon: MessageCircleHeart,
    title: 'AI Stylist Chat',
    desc: 'Ask for outfit ideas by occasion — "formal meeting", "party tonight" — and get advice that knows what\'s in your closet.',
    color: 'from-pink/25 to-pink/5',
    iconColor: 'text-pink',
    span: 'lg:col-span-2',
  },
  {
    icon: CalendarClock,
    title: 'Style Planner',
    desc: "Plan outfits for upcoming events, attach the pieces you'll wear, and get a reminder before you need to be ready.",
    color: 'from-mint/25 to-mint/5',
    iconColor: 'text-mint',
    span: '',
  },
  {
    icon: BarChart3,
    title: 'Wardrobe Analytics',
    desc: 'See your most and least worn pieces, wear trends over time, and which items are quietly gathering dust.',
    color: 'from-magenta/25 to-magenta/5',
    iconColor: 'text-magenta',
    span: '',
  },
  {
    icon: ScanFace,
    title: 'Virtual Try-On',
    desc: 'Generate a realistic AI image of yourself wearing the full outfit before you ever put it on.',
    color: 'from-gold/30 to-gold/5',
    iconColor: 'text-gold-dark',
    premium: true,
    span: 'lg:col-span-2',
  },
]

export default function Features() {
  return (
    <section id="features" className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="text-xs font-bold uppercase tracking-widest text-violet">Everything you need</p>
          <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
            One app. Every part of getting dressed.
          </h2>
          <p className="mt-4 text-muted">
            From cataloguing your closet to seeing yourself in the final look — AI Outfit Planner
            handles the whole styling loop.
          </p>
        </motion.div>

        <div className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 lg:auto-rows-[minmax(190px,auto)]">
          {FEATURES.map((feature, i) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.5, delay: (i % 4) * 0.08 }}
                className={`glass shadow-glass group relative flex flex-col overflow-hidden rounded-3xl p-7 transition-transform hover:-translate-y-1 ${feature.span} ${
                  feature.premium ? 'ring-1 ring-gold/30' : ''
                }`}
              >
                {feature.premium && (
                  <Link
                    to="/premium"
                    className="absolute right-5 top-5 flex items-center gap-1 rounded-full bg-gradient-to-r from-gold to-gold-dark px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-white"
                  >
                    <Crown className="h-2.5 w-2.5" strokeWidth={2.5} />
                    Premium
                  </Link>
                )}
                <div className={`mb-5 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br ${feature.color} ${feature.big ? 'h-14 w-14' : ''}`}>
                  <Icon className={`${feature.big ? 'h-7 w-7' : 'h-6 w-6'} ${feature.iconColor}`} strokeWidth={1.75} />
                </div>
                <h3 className={`font-display font-semibold text-ink ${feature.big ? 'text-2xl' : 'text-lg'}`}>{feature.title}</h3>
                <p className={`mt-2.5 leading-relaxed text-muted ${feature.big ? 'max-w-sm text-[15px]' : 'text-sm'}`}>{feature.desc}</p>

                {feature.tags && (
                  <div className="mt-auto flex flex-wrap gap-2 pt-6">
                    {feature.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full border border-violet/25 bg-white/5 px-3 py-1 text-[11px] font-medium text-ink-soft"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
